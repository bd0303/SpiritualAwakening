﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour {

    public float speed = 5f;
    public int footstep = 0;
    public AudioClip footstepSound;
    private AudioSource source;
    private float volLowRange = .5f;
    private float volHighRange = 1.5f;

    // Use this for initialization
    void Start () {
        source = GetComponent<AudioSource>();
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.A))
        {
            if ((footstep % 2) == 0 && !GetComponent<AudioSource>().isPlaying) { source.PlayOneShot(footstepSound, Random.Range(volLowRange, volHighRange));}
            footstep++;
            transform.Translate(Vector3.left * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.D))
        {
            if ((footstep % 2) == 0 && !GetComponent<AudioSource>().isPlaying) { source.PlayOneShot(footstepSound, Random.Range(volLowRange, volHighRange));}
            footstep++;
            transform.Translate(Vector3.right * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.W))
        {
            if ((footstep % 2) == 0 && !GetComponent<AudioSource>().isPlaying) { source.PlayOneShot(footstepSound, Random.Range(volLowRange, volHighRange)); }
            footstep++;
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S))
        {
            if ((footstep % 2) == 0 && !GetComponent<AudioSource>().isPlaying) { source.PlayOneShot(footstepSound, Random.Range(volLowRange, volHighRange)); }
            footstep++;
            transform.Translate(Vector3.back * speed * Time.deltaTime);
        }
    }
}
