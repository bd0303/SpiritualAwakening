﻿using UnityEngine;
using System.Collections;

public class Door : MonoBehaviour {

    public bool open = false;
    public float doorOpenAngle = 90f;
    public float doorCloseAngle = 0f;
    public float smooth = 2f;
    public AudioClip openSound;
    private AudioSource source;

    public Texture[] textures;
    public int currentTexture;

    // Use this for initialization
    void Start () {
        source = GetComponent<AudioSource>();
    }
	
    public void ChangeDoorState() {
        open = !open;
        source.PlayOneShot(openSound, .6f);
    }

	// Update is called once per frame
	void Update () {
	    if (open) {
            /*Quaternion targetRotation = Quaternion.Euler(0,doorOpenAngle,0);
            transform.localRotation = Quaternion.Slerp(transform.localRotation, targetRotation, smooth * Time.deltaTime);*/
            currentTexture++;
            currentTexture %= textures.Length;
            GetComponent<Renderer>().material.mainTexture = textures[0];
        }
        /*else {
            Quaternion targetRotation2 = Quaternion.Euler(0, doorCloseAngle, 0);
            transform.localRotation = Quaternion.Slerp(transform.localRotation, targetRotation2, smooth * Time.deltaTime);
        }*/
	}
}
